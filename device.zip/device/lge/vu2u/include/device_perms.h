#define PROPERTY_PERMS_APPEND { "persist.camera.",      AID_MEDIA,    0 },
